//
//  TInstallSDK.h
//  TInstallSDK
//
//  Created by fx on 2020/12/21.
//

#import <Foundation/Foundation.h>

//! Project version number for TInstallSDK.
FOUNDATION_EXPORT double TInstallSDKVersionNumber;

//! Project version string for TInstallSDK.
FOUNDATION_EXPORT const unsigned char TInstallSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TInstallSDK/PublicHeader.h>


#import <TInstallSDK/TInstall.h>
