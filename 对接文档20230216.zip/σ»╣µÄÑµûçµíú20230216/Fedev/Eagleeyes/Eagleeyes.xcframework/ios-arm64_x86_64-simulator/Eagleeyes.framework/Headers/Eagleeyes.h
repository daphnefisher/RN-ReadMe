//
//  Eagleeyes.h
//  Eagleeyes
//
//  Created by E2 - Jackie on 30/03/2018.
//  Copyright © 2018 E2. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Eagleeyes.
FOUNDATION_EXPORT double EagleeyesVersionNumber;

//! Project version string for Eagleeyes.
FOUNDATION_EXPORT const unsigned char EagleeyesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Eagleeyes/PublicHeader.h>

#import <Eagleeyes/DevicePrint.h>
